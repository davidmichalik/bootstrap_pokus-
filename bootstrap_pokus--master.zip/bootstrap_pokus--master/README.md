# Povinné zadanie C - bootstrap (8.5.2016)

Oboznámte sa s dostupnými materiálmi o Bootstrape.

Vytvorte vzdialený repozitár na GitHube s názvom bootstrap_pokus.


Vytvorte nasledujúce stránky s použitím Twitter Bootstrap:


1. index.html bude obsahovať horné horizontálne menu


	slideshow


	3 marketing panels


	galériu projektov (obrázky v mriežke 3x3)


	pätu s adresou a odkazmi na sociálne siete


2. contact.html


	kontaktný formulár s adresou


	obrázky


	prípadne s mapou


3. report.html


	tri záložky (tabs) alebo accordion


	na prvej záložke tabuľku so stránkovaním, v poslednom stĺpci vytvorte tlačidlá v podobe ikon pre editáciu, odstránenie a zviditeľnenie záznamu


	na druhej záložke formulár,s prvkami, ktoré umožnia naplniť tabuľku


	čokoľvek ďalšie


3. Zmeňte vzhľad vytvorených stránok pomocou niektorej z tém dostupných na stránke http://bootswatch.com/.


4. Všetky zmeny musia byť zaznamenané v GitHube v podobe aspoň 20 commitov.


5. Ak ste sa rozhodli použiť Pivotal Tracker v tomto zadaní, vytvorte aspoň 20 príbehov.


6. Do tejto aktivity vložte link na vzdialený repozitár s Vašim riešením.


7. Stránky uploadujte  na Váš študentský web a do tejto aktivity pridajte link, kde sa výsledok Vašej práce nachádza.


8. Zároveň vložte do tejto aktivity skomprinovaný archív vytvorených stránok.


 
